# platzi-intro_ml

Hola a tod@s!
el presente proyecto de github, tiene dos carpetas con los proyectos presentados en el curso de Intro a Machine Learning en Platzi! Los detalles aquí:https://platzi.com/clases/machine-learning/

Machine Learning principalmente se divide en dos categorías según el tipo de datos que tenga, estas dos categorías son: Supervisado y No Supervisado, por eso tenemos dos proyectos: el proyecto para el ML Supervisado y el otro folder para el No Supervisado.
Cada uno de los notebooks corresponde a las clases desarrolladas en el curso.

